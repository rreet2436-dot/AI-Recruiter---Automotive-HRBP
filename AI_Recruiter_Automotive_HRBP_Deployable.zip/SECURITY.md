# Production security checklist

- HTTPS
- SSO/RBAC
- Private network for PostgreSQL, Qdrant and Ollama
- Encrypted CV storage and backups
- Applicant-data retention/deletion policy
- Restricted access to CVs, assessments and transcripts
- No protected characteristics in screening
- Model/version audit log
- Screening validation against labelled data
- Human approval before final selection and adverse employment actions
- Candidate correction/appeal path for data errors
- Review applicable privacy/employment requirements
- Review model and dependency licences before commercial deployment
