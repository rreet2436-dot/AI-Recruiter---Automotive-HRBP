# AI Recruiter — Automotive HRBP Edition

A self-hosted recruitment automation MVP using local/open-source components:
FastAPI, PostgreSQL, Qdrant, Ollama, PyMuPDF, python-docx, SMTP/Mailpit and a browser dashboard.

## One-command hiring

Enter:

Hire an HR Manager with 10 years experience in an automotive company for an HRBP role in Pune.

The system:
1. Converts the request to a structured job specification.
2. Generates the JD.
3. Builds a screening model.
4. Screens the candidate database.
5. Produces evidence-backed scores.
6. Generates candidate communications.
7. Creates interview slots.
8. Books interviews and generates calendar ICS files.
9. Generates an HRBP assessment.
10. Stores an audit trail.

## Quick start

Install Docker Desktop, then:

```bash
docker compose up -d --build
docker compose exec ollama ollama pull qwen3:8b
docker compose exec ollama ollama pull nomic-embed-text
docker compose exec api python -m app.seed
```

Open:
- AI Recruiter: http://localhost:8080
- Mailpit: http://localhost:8025
- Qdrant: http://localhost:6333/dashboard

The included candidate profiles are synthetic demonstrations.

## Production

Before exposing this system to real applicants:
- use HTTPS and SSO/RBAC;
- change APP_SECRET;
- keep PostgreSQL/Qdrant/Ollama on a private network;
- replace Mailpit with corporate SMTP;
- connect your corporate calendar API/CalDAV;
- encrypt CVs and backups;
- define applicant-data retention/deletion;
- validate extraction and screening against labelled historical data;
- keep human approval for final employment decisions and adverse outcomes;
- record model/version and audit information;
- review applicable employment/privacy requirements and model licences.

External SMTP/calendar credentials are intentionally not embedded in the package because they are secrets. The local deployment is nevertheless runnable end-to-end with Mailpit and ICS scheduling.
