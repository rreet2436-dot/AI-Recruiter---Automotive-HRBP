#!/usr/bin/env bash
set -e
docker compose up -d --build
sleep 8
docker compose exec ollama ollama pull qwen3:8b
docker compose exec ollama ollama pull nomic-embed-text
docker compose exec api python -m app.seed
echo "AI Recruiter: http://localhost:8080"
echo "Mailpit: http://localhost:8025"
