docker compose up -d --build
Start-Sleep -Seconds 8
docker compose exec ollama ollama pull qwen3:8b
docker compose exec ollama ollama pull nomic-embed-text
docker compose exec api python -m app.seed
Write-Host "AI Recruiter: http://localhost:8080"
Write-Host "Mailpit: http://localhost:8025"
