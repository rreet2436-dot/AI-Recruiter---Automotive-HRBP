import os,uuid,smtplib
from pathlib import Path
from email.message import EmailMessage
from datetime import datetime,timedelta
from fastapi import FastAPI,Depends,UploadFile,File,HTTPException
from fastapi.responses import FileResponse,HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select,func
from .db import init_db,get_db
from .models import Job,Candidate,CandidateScore,InterviewSlot
from .schemas import RecruitmentCommand,SlotCreate,BookSlot
from .cv import extract_text
from .ai import parse_cv,make_email
from .pipeline import run_recruitment,create_assessment

app=FastAPI(title="AI Recruiter — Automotive HRBP")
BASE=Path(__file__).resolve().parent; DATA=Path(os.getenv("STORAGE_DIR","/data"))
CV_DIR=DATA/"candidates"; OUTBOX=DATA/"outbox"; CV_DIR.mkdir(parents=True,exist_ok=True); OUTBOX.mkdir(parents=True,exist_ok=True)
app.mount("/static",StaticFiles(directory=str(BASE/"static")),name="static")
@app.on_event("startup")
def startup(): init_db()
@app.get("/",response_class=HTMLResponse)
def home(): return FileResponse(BASE/"static"/"index.html")
@app.get("/health")
def health(): return {"status":"ok"}
@app.post("/api/recruitment/command")
def command(payload:RecruitmentCommand,db=Depends(get_db)):
    job,results=run_recruitment(db,payload.request)
    return {"job_id":job.id,"status":job.status,"spec":job.spec,"jd":job.jd,"results":results}
@app.post("/api/candidates/upload")
async def upload_candidate(file:UploadFile=File(...),db=Depends(get_db)):
    suffix=Path(file.filename or "").suffix.lower()
    if suffix not in {".pdf",".docx",".txt",".md"}: raise HTTPException(400,"Supported formats: PDF, DOCX, TXT, MD")
    path=CV_DIR/f"{uuid.uuid4().hex}{suffix}"; path.write_bytes(await file.read())
    text=extract_text(str(path)); d=parse_cv(text)
    c=Candidate(name=d["name"],email=d["email"],phone=d["phone"],location=d["location"],
    current_title=d["current_title"],current_company=d["current_company"],total_experience=d["total_experience"],
    automotive_experience=d["automotive_experience"],hrbp_experience=d["hrbp_experience"],plant_hr_experience=d["plant_hr_experience"],
    extracted=d,cv_text=text,cv_path=str(path))
    db.add(c); db.commit(); db.refresh(c); return {"candidate_id":c.id,"candidate":d}
@app.get("/api/jobs/{job_id}")
def get_job(job_id:int,db=Depends(get_db)):
    job=db.get(Job,job_id)
    if not job: raise HTTPException(404,"Job not found")
    rows=db.execute(select(CandidateScore).where(CandidateScore.job_id==job_id).order_by(CandidateScore.score.desc())).scalars().all()
    return {"job_id":job.id,"request":job.request_text,"spec":job.spec,"jd":job.jd,
            "scores":[{"candidate_id":x.candidate_id,"score":x.score,"eligible":x.eligible,"decision":x.decision,"evidence":x.evidence} for x in rows]}
@app.get("/api/dashboard")
def dashboard(db=Depends(get_db)):
    return {"jobs":db.scalar(select(func.count(Job.id))) or 0,
    "candidates":db.scalar(select(func.count(Candidate.id))) or 0,
    "shortlisted":db.scalar(select(func.count(CandidateScore.id)).where(CandidateScore.decision=="SHORTLIST")) or 0,
    "interviews_booked":db.scalar(select(func.count(InterviewSlot.id)).where(InterviewSlot.booked==True)) or 0}
@app.post("/api/interviews/slots")
def create_slot(p:SlotCreate,db=Depends(get_db)):
    s=InterviewSlot(job_id=p.job_id,starts_at=datetime.fromisoformat(p.starts_at),duration_minutes=p.duration_minutes,interviewer=p.interviewer)
    db.add(s);db.commit();db.refresh(s);return {"slot_id":s.id,"starts_at":s.starts_at.isoformat()}
@app.get("/api/interviews/slots/{job_id}")
def slots(job_id:int,db=Depends(get_db)):
    return [{"id":s.id,"starts_at":s.starts_at.isoformat(),"duration":s.duration_minutes,"interviewer":s.interviewer}
    for s in db.execute(select(InterviewSlot).where(InterviewSlot.job_id==job_id,InterviewSlot.booked==False).order_by(InterviewSlot.starts_at)).scalars().all()]
@app.post("/api/interviews/book/{slot_id}")
def book(slot_id:int,p:BookSlot,db=Depends(get_db)):
    slot=db.get(InterviewSlot,slot_id); candidate=db.get(Candidate,p.candidate_id); job=db.get(Job,slot.job_id) if slot else None
    if not slot or not candidate or not job: raise HTTPException(404,"Slot, candidate or job not found")
    if slot.booked: raise HTTPException(409,"Slot already booked")
    slot.booked=True;slot.candidate_id=candidate.id;db.commit()
    end=slot.starts_at+timedelta(minutes=slot.duration_minutes)
    ics=f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//AI Recruiter//EN
BEGIN:VEVENT
UID:ai-recruiter-{slot.id}@local
DTSTAMP:{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}
DTSTART:{slot.starts_at.strftime('%Y%m%dT%H%M%S')}
DTEND:{end.strftime('%Y%m%dT%H%M%S')}
SUMMARY:Interview - {job.spec.get('job_title','HR Interview')}
DESCRIPTION:AI Recruiter interview. Final employment decision remains with the authorised hiring team.
END:VEVENT
END:VCALENDAR
"""
    fp=OUTBOX/f"interview_{slot.id}.ics";fp.write_text(ics)
    send_email(candidate.email,"Interview scheduled - HR Manager HRBP",
               make_email(candidate.name,job.spec)+f"\nInterview: {slot.starts_at.strftime('%d %B %Y, %I:%M %p')}\n",str(fp))
    return {"status":"booked","candidate":candidate.name,"email":candidate.email,"ics":str(fp)}
def send_email(to,subject,body,attachment=None):
    host=os.getenv("SMTP_HOST","localhost");port=int(os.getenv("SMTP_PORT","1025"));sender=os.getenv("SMTP_FROM","AI Recruiter <ai-recruiter@local.test>")
    m=EmailMessage();m["From"]=sender;m["To"]=to;m["Subject"]=subject;m.set_content(body)
    if attachment:
        p=Path(attachment);m.add_attachment(p.read_bytes(),maintype="text",subtype="calendar",filename=p.name)
    try:
        with smtplib.SMTP(host,port,timeout=10) as s:s.send_message(m)
        return True
    except Exception:return False
@app.post("/api/assessment/{job_id}/{candidate_id}")
def assessment(job_id:int,candidate_id:int,db=Depends(get_db)):
    a=create_assessment(db,job_id,candidate_id);return {"assessment_id":a.id,"questions":a.questions}
