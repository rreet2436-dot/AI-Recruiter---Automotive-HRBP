import os
from sqlalchemy import select
from qdrant_client import QdrantClient,models
from .ai import make_job_spec,make_jd,embed
from .models import Job,Candidate,CandidateScore,AuditLog
from .scoring import score_candidate
QURL=os.getenv("QDRANT_URL","http://localhost:6333"); COLLECTION="candidate_profiles"
qdrant=QdrantClient(url=QURL)
def ensure_collection():
    try:qdrant.get_collection(COLLECTION)
    except:qdrant.create_collection(COLLECTION,vectors_config=models.VectorParams(size=768,distance=models.Distance.COSINE))
def audit(db,jid,action,detail):
    db.add(AuditLog(job_id=jid,action=action,detail=detail)); db.commit()
def run_recruitment(db,request):
    ensure_collection()
    spec=make_job_spec(request); jd=make_jd(spec)
    job=Job(request_text=request,spec=spec,jd=jd,status="screening"); db.add(job); db.commit(); db.refresh(job)
    audit(db,job.id,"JOB_CREATED",{"spec":spec})
    results=[]
    for c in db.execute(select(Candidate)).scalars().all():
        total,eligible,decision,evidence=score_candidate(c,spec)
        db.add(CandidateScore(job_id=job.id,candidate_id=c.id,score=total,eligible=eligible,decision=decision,evidence=evidence))
        results.append({"candidate_id":c.id,"name":c.name,"email":c.email,"score":total,"eligible":eligible,"decision":decision,"evidence":evidence})
        try:
            v=embed(c.cv_text[:12000])
            qdrant.upsert(COLLECTION,[models.PointStruct(id=c.id,vector=v,payload={"candidate_id":c.id,"name":c.name})])
        except Exception: pass
    db.commit(); results.sort(key=lambda x:x["score"],reverse=True)
    job.status="shortlisted"; db.commit()
    audit(db,job.id,"SCREENING_COMPLETED",{"candidate_count":len(results)})
    return job,results
def create_assessment(db,job_id,candidate_id):
    from .models import Assessment
    qs=[
    "A 3,000-employee automotive plant has 18% attrition and 8% absenteeism. What would you diagnose first and why?",
    "A union settlement is approaching while productivity is below target. Explain your stakeholder and negotiation strategy.",
    "Design a 90-day HRBP plan for a plant where workforce cost is rising faster than production volume.",
    "Give one example of an HR metric you converted into a business decision. Quantify the result.",
    "Describe a serious employee-relations issue you handled. What was the business impact?"
    ]
    a=Assessment(job_id=job_id,candidate_id=candidate_id,questions=qs); db.add(a); db.commit(); db.refresh(a); return a
