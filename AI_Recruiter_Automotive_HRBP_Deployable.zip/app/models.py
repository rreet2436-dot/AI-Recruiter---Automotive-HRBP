from datetime import datetime
from sqlalchemy import String, Text, Float, Integer, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

class Job(Base):
    __tablename__="jobs"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    request_text: Mapped[str]=mapped_column(Text)
    spec: Mapped[dict]=mapped_column(JSON)
    jd: Mapped[str]=mapped_column(Text)
    status: Mapped[str]=mapped_column(String(40),default="created")
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class Candidate(Base):
    __tablename__="candidates"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    name: Mapped[str]=mapped_column(String(200))
    email: Mapped[str]=mapped_column(String(300))
    phone: Mapped[str]=mapped_column(String(80),default="")
    location: Mapped[str]=mapped_column(String(200),default="")
    current_title: Mapped[str]=mapped_column(String(200),default="")
    current_company: Mapped[str]=mapped_column(String(300),default="")
    total_experience: Mapped[float]=mapped_column(Float,default=0)
    automotive_experience: Mapped[float]=mapped_column(Float,default=0)
    hrbp_experience: Mapped[float]=mapped_column(Float,default=0)
    plant_hr_experience: Mapped[float]=mapped_column(Float,default=0)
    extracted: Mapped[dict]=mapped_column(JSON,default=dict)
    cv_text: Mapped[str]=mapped_column(Text,default="")
    cv_path: Mapped[str]=mapped_column(String(500),default="")
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class CandidateScore(Base):
    __tablename__="candidate_scores"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    job_id: Mapped[int]=mapped_column(ForeignKey("jobs.id"))
    candidate_id: Mapped[int]=mapped_column(ForeignKey("candidates.id"))
    score: Mapped[float]=mapped_column(Float)
    eligible: Mapped[bool]=mapped_column(Boolean,default=False)
    decision: Mapped[str]=mapped_column(String(40))
    evidence: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class AuditLog(Base):
    __tablename__="audit_log"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    job_id: Mapped[int]=mapped_column(ForeignKey("jobs.id"),nullable=True)
    action: Mapped[str]=mapped_column(String(100))
    detail: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class InterviewSlot(Base):
    __tablename__="interview_slots"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    job_id: Mapped[int]=mapped_column(ForeignKey("jobs.id"))
    starts_at: Mapped[datetime]=mapped_column(DateTime)
    duration_minutes: Mapped[int]=mapped_column(Integer,default=60)
    interviewer: Mapped[str]=mapped_column(String(200))
    booked: Mapped[bool]=mapped_column(Boolean,default=False)
    candidate_id: Mapped[int]=mapped_column(ForeignKey("candidates.id"),nullable=True)

class Assessment(Base):
    __tablename__="assessments"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    job_id: Mapped[int]=mapped_column(ForeignKey("jobs.id"))
    candidate_id: Mapped[int]=mapped_column(ForeignKey("candidates.id"))
    questions: Mapped[list]=mapped_column(JSON)
    result: Mapped[dict]=mapped_column(JSON,default=dict)
    status: Mapped[str]=mapped_column(String(40),default="created")
