import os,json,requests
OLLAMA_URL=os.getenv("OLLAMA_URL","http://localhost:11434")
MODEL=os.getenv("OLLAMA_MODEL","qwen3:8b")
EMBED=os.getenv("EMBEDDING_MODEL","nomic-embed-text")

SYSTEM="""You are an enterprise recruitment AI for an Indian automotive manufacturing company.
Use only supplied evidence. Never invent experience, employers, dates or qualifications.
Never infer or use protected characteristics in recruitment decisions.
Return concise structured outputs."""
def chat(prompt,schema=None):
    p={"model":MODEL,"messages":[{"role":"system","content":SYSTEM},{"role":"user","content":prompt}],
       "stream":False,"options":{"temperature":0.1}}
    if schema: p["format"]=schema
    r=requests.post(f"{OLLAMA_URL}/api/chat",json=p,timeout=300); r.raise_for_status()
    c=r.json()["message"]["content"]
    try:return json.loads(c)
    except:return c
def embed(text):
    r=requests.post(f"{OLLAMA_URL}/api/embed",json={"model":EMBED,"input":text},timeout=300)
    r.raise_for_status(); return r.json()["embeddings"][0]

JOB_SCHEMA={"type":"object","properties":{
"job_title":{"type":"string"},"location":{"type":"string"},"minimum_experience":{"type":"number"},
"target_experience":{"type":"number"},"maximum_experience":{"type":"number"},"industry":{"type":"string"},
"mandatory":{"type":"array","items":{"type":"string"}},"preferred":{"type":"array","items":{"type":"string"}},
"responsibilities":{"type":"array","items":{"type":"string"}},"success_metrics":{"type":"array","items":{"type":"string"}}},
"required":["job_title","location","minimum_experience","target_experience","maximum_experience",
"industry","mandatory","preferred","responsibilities","success_metrics"]}

def make_job_spec(request):
    return chat("""Convert this hiring command into a precise recruitment specification.
If reasonable operational details are missing, derive them from the role. Do not ask a follow-up.
Use Indian automotive manufacturing context.
COMMAND:
"""+request,JOB_SCHEMA)

def make_jd(spec):
    return chat("""Write a complete candidate-facing JD from this specification.
Include role summary, responsibilities, mandatory requirements, preferred requirements,
business impact, success measures, location and experience. Do not include protected-characteristic preferences.
SPECIFICATION:
"""+json.dumps(spec,indent=2))

def parse_cv(text):
    schema={"type":"object","properties":{
"name":{"type":"string"},"email":{"type":"string"},"phone":{"type":"string"},"location":{"type":"string"},
"current_title":{"type":"string"},"current_company":{"type":"string"},"total_experience":{"type":"number"},
"automotive_experience":{"type":"number"},"hrbp_experience":{"type":"number"},"plant_hr_experience":{"type":"number"},
"skills":{"type":"array","items":{"type":"string"}},"evidence":{"type":"array","items":{"type":"string"}},
"education":{"type":"array","items":{"type":"string"}},"notice_period":{"type":"string"}},
"required":["name","email","phone","location","current_title","current_company","total_experience",
"automotive_experience","hrbp_experience","plant_hr_experience","skills","evidence","education","notice_period"]}
    return chat("""Extract a factual candidate profile from this CV. Calculate experience from stated dates when possible.
If dates are unclear, use 0 rather than inventing. Keep evidence factual and short.
CV:
"""+text,schema)

def make_email(name,job):
    return f"""Dear {name},

Thank you for your interest in the {job['job_title']} opportunity.

Based on the information provided in your profile, we would like to invite you to the next stage of our recruitment process.

Role: {job['job_title']}
Location: {job['location']}

Regards,
Talent Acquisition
"""
