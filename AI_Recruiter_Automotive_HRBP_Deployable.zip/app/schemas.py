from pydantic import BaseModel, Field
class RecruitmentCommand(BaseModel):
    request: str=Field(min_length=10)
    auto_run: bool=True
class SlotCreate(BaseModel):
    job_id:int
    starts_at:str
    interviewer:str
    duration_minutes:int=60
class BookSlot(BaseModel):
    candidate_id:int
