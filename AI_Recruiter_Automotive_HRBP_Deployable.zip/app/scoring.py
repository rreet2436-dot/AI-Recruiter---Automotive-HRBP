def score_candidate(c,spec):
    t=c.cv_text.lower()
    p={}
    p["automotive"]=min(20,c.automotive_experience/max(spec["target_experience"],1)*20)
    p["hrbp"]=min(20,c.hrbp_experience/6*20)
    p["experience"]=10 if c.total_experience>=spec["minimum_experience"] else max(0,c.total_experience/spec["minimum_experience"]*10)
    p["plant_hr"]=10 if any(x in t for x in ["plant hr","plant human resources","shopfloor hr"]) else 0
    p["employee_relations"]=10 if any(x in t for x in ["employee relations","grievance","disciplinary"]) else 0
    p["industrial_relations"]=8 if any(x in t for x in ["industrial relations","union","collective bargaining"]) else 0
    p["labour_compliance"]=7 if any(x in t for x in ["labour law","labor law","statutory compliance","factory act","labour compliance"]) else 0
    p["workforce_planning"]=5 if "workforce planning" in t or "manpower planning" in t else 0
    p["talent_management"]=5 if "talent management" in t or "succession" in t else 0
    p["hr_analytics"]=3 if "hr analytics" in t or "people analytics" in t else 0
    p["multi_plant"]=2 if any(x in t for x in ["multi-plant","multi plant","multiple plants"]) else 0
    total=round(sum(p.values()),2)
    eligible=c.total_experience>=spec["minimum_experience"] and c.automotive_experience>0 and c.hrbp_experience>0
    decision="SHORTLIST" if eligible and total>=70 else ("REVIEW" if eligible else "NOT_ELIGIBLE")
    return total,eligible,decision,{"criterion_scores":p}
