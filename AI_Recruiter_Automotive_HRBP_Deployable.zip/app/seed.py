from .db import SessionLocal,init_db
from .models import Candidate
init_db();db=SessionLocal()
rows=[
("Arun Mehta","arun.mehta@example.local","Pune","Senior HR Manager","AutoDrive Components Ltd",10.8,8.1,6.2,6.5,"Senior HR leader with 10.8 years HR experience, 8.1 years automotive manufacturing, 6.2 years HRBP, 6.5 years plant HR. Workforce planning, employee relations, union negotiations, labour compliance, talent management, performance management, HR analytics and multi-plant HR."),
("Neha Kulkarni","neha.kulkarni@example.local","Pune","HR Business Partner","Mobility Systems India",9.4,6.7,5.3,4.8,"HRBP with 9.4 years HR, 6.7 automotive, 5.3 HRBP and 4.8 plant HR. Plant HR, grievance handling, disciplinary processes, workforce planning, labour law compliance, performance management, talent reviews and HR dashboards."),
("Vikram Shah","vikram.shah@example.local","Nashik","HR Manager","Precision Auto Systems",12.2,10.4,4.1,8.2,"12.2 years HR, 10.4 automotive manufacturing, 4.1 HRBP and 8.2 plant HR. Industrial relations, union settlements, statutory compliance, plant HR and multi-plant support."),
("Priya Nair","priya.nair@example.local","Chennai","Senior HRBP","Industrial Mobility Technologies",10.1,7.8,7.1,5.4,"10.1 years HR, 7.8 automotive manufacturing, 7.1 HRBP and 5.4 plant HR. Business partnering, workforce planning, employee relations, talent management, succession, HR analytics and industrial relations."),
("Rohit Verma","rohit.verma@example.local","Mumbai","HR General Manager","Engineering Services Group",11.5,1.2,7.8,1.0,"11.5 years HR, 1.2 automotive, 7.8 HRBP and 1 year plant HR. Strong talent and performance management, but limited automotive manufacturing and plant HR exposure.")
]
for r in rows:
    if not db.query(Candidate).filter(Candidate.email==r[1]).first():
        db.add(Candidate(name=r[0],email=r[1],location=r[2],current_title=r[3],current_company=r[4],
        total_experience=r[5],automotive_experience=r[6],hrbp_experience=r[7],plant_hr_experience=r[8],
        extracted={"skills":[],"evidence":[r[9]]},cv_text=r[9],cv_path="synthetic-demo"))
db.commit();print("Synthetic demonstration candidates loaded.")
