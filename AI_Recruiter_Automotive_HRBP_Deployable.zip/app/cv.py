from pathlib import Path
import fitz
from docx import Document
def extract_text(path):
    p=Path(path)
    if p.suffix.lower()==".pdf":
        d=fitz.open(path); return "\n".join(x.get_text() for x in d)
    if p.suffix.lower()==".docx":
        d=Document(path); return "\n".join(x.text for x in d.paragraphs)
    if p.suffix.lower() in {".txt",".md"}: return p.read_text(errors="ignore")
    raise ValueError("Supported CV formats: PDF, DOCX, TXT, MD")
